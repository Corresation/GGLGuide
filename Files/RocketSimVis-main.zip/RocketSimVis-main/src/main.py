import os
import math
import random
import threading
import sys 
import argparse
import copy
import struct
import time

from const import *
from shaders import *
from arena_shaders import *
from socket_listener import SocketListener
from state_manager import *
from ribbon import *
from outline_renderer import OutlineRenderer
import ui
from ui import get_ui, QUIBarWidget, QRSVWindow
from config import Config, ConfigVal

import moderngl
import moderngl_window
import moderngl_window.loaders.scene.wavefront as wvf
from moderngl_window import resources
from moderngl_window.meta import TextureDescription

from PyQt5 import QtOpenGL, QtWidgets
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtGui import QScreen, QColor, QCursor

from OpenGL.GL import *
from OpenGL.GLU import *

import numpy as np

from pyrr import Quaternion, Matrix33, Matrix44, Vector3, Vector4
import pyrr

import pywavefront

# TODO: Move
def safe_normalize(vec: pyrr.Vector3):
    length = max(vec.length, 1e-6)
    return vec / length

# TODO: Move game logic out of here
class QRSVGLWidget(QtOpenGL.QGLWidget):
    def __init__(self, screen: QScreen):

        self.config = Config()

        self.spectate_count = 0
        self.spectate_idx = 0
        self.prev_interp_ratio = 0
        self.car_cam_time = 0
        
        # Camera modes: 0=Manual, 1=Auto-focus, 2=Free
        self.camera_mode = 0
        self.free_cam_pos = Vector3((0, 0, 500))  # Start above ground center
        self.free_cam_yaw = 0.0
        self.free_cam_pitch = -0.3  # Look down slightly
        self.keys_pressed = set()
        self.mouse_last_x = None
        self.mouse_last_y = None
        
        # Free camera movement speed
        self.free_cam_speed = 1200.0  # Slower for better control
        
        # Window focus tracking for free cam (prevents hover-activation)
        self.window_clicked_focus = False
        
        # Window state tracking for fullscreen
        self.was_maximized_before_fullscreen = False
        
        self.last_render_time = time.time()
        self.fps_counter = 0
        self.last_fps = 0
        self.prev_state = None # type: GameState
        
        # Score tracking
        self.blue_score = 0
        self.orange_score = 0
        self.last_ball_pos = None
        self.goal_scored_cooldown = 0
        
        # Goal explosion state
        self.goal_explosion_active = False
        self.goal_explosion_time = 0
        self.goal_explosion_team = 0  # 0=blue, 1=orange
        self.goal_explosion_pos = Vector3((0, 0, 0))

        ########################################################################

        self.samples = 4

        fmt = QtOpenGL.QGLFormat()
        fmt.setVersion(3, 3)
        fmt.setProfile(QtOpenGL.QGLFormat.CoreProfile)
        fmt.setDepthBufferSize(24)
        fmt.setStencilBufferSize(8)
        fmt.setDoubleBuffer(True)
        fmt.setSwapInterval(1)

        if self.samples > 1:
            fmt.setSampleBuffers(True)
            fmt.setSamples(int(self.samples))

        super(QRSVGLWidget, self).__init__(fmt, None)

        self.setMouseTracking(True)

    def load_texture_2d(self, path: str) -> moderngl.Texture:
        return resources.textures.load(TextureDescription(path=path))

    def initializeGL(self):

        self.ctx = moderngl.create_context()
        moderngl_window.activate_context(None, self.ctx)

        ##########################################

        print("Creating shader programs...")

        self.prog = self.ctx.program(
            vertex_shader=VERT_SHADER,
            fragment_shader=FRAG_SHADER,
        )

        self.prog_arena = self.ctx.program(
            vertex_shader=ARENA_VERT_SHADER,
            fragment_shader=ARENA_FRAG_SHADER,
            geometry_shader=ARENA_GEOM_SHADER
        )

        print("Creating outline renderer...")
        #self.outline_renderer = OutlineRenderer(self.ctx, (self.width(), self.height())) # TODO: Fix resizing bugs
        self.outline_renderer = None # Disabled due to weird shader compilation issues

        print("Linking shader varaibles...")
        self.pr_m_vp = self.prog['m_vp']
        self.pr_m_model = self.prog['m_model']
        self.pr_global_color = self.prog['globalColor']
        self.pr_camera_pos = self.prog['cameraPos']

        self.pra_m_vp = self.prog_arena['m_vp']
        self.pra_m_model = self.prog_arena['m_model']
        self.pra_ball_pos = self.prog_arena['ballPos']

        ##########################################

        self.ball_ribbon = RibbonEmitter()
        self.car_ribbons = []

        print("Data path:", DATA_DIR_PATH)
        print("Loading models and textures...")

        self.vaos = {}
        self.load_vao("ArenaMeshCustom.obj", self.prog_arena)

        self.load_vao("Octane.obj")
        self.load_vao("Ball.obj")

        self.load_vao("BoostPad_Small_0.obj")
        self.load_vao("BoostPad_Small_1.obj")
        self.load_vao("BoostPad_Big_0.obj")
        self.load_vao("BoostPad_Big_1.obj")

        self.ts_octane = [
            self.load_texture_2d(DATA_DIR_PATH + "T_Octane_B.png"),
            self.load_texture_2d(DATA_DIR_PATH + "T_Octane_O.png")
        ]
        self.t_ball = self.load_texture_2d(DATA_DIR_PATH + "T_Ball.png")
        self.t_boostpad = self.load_texture_2d(DATA_DIR_PATH + "T_BoostPad.png")
        self.t_boost_glow = self.load_texture_2d(DATA_DIR_PATH + "T_Boost_Glow.png")
        self.t_black = self.load_texture_2d(DATA_DIR_PATH + "T_Black.png")
        self.t_none = self.load_texture_2d(DATA_DIR_PATH + "T_None.png")

        ############################################

        # Make ribbon mesh
        self.ribbon_max_verts = 1000
        self.ribbon_verts = np.random.randn(self.ribbon_max_verts * 3) * 100
        self.ribbon_vbo = self.ctx.buffer(self.ribbon_verts.astype('f4'))
        self.ribbon_vao = self.ctx.simple_vertex_array(self.prog, self.ribbon_vbo, "in_position")
        self.vaos['ribbon'] = self.ribbon_vao

        # Make debug lines mesh
        self.lines_max_verts = RenderState.MAX_LINES * 2
        self.lines_verts = np.random.randn(self.lines_max_verts * 3) * 100
        self.lines_vbo = self.ctx.buffer(self.lines_verts.astype('f4'))
        self.lines_vao = self.ctx.simple_vertex_array(self.prog, self.lines_vbo, "in_position")
        self.vaos['render_lines'] = self.lines_vao

        ############################################

        # Auto-enable multisampling if we have multiple samples
        self.ctx.multisample = self.samples > 1

        ############################################

        print("Done.")

    def load_vao(self, model_name, program = None):
        loader = wvf.Loader(wvf.SceneDescription(path = DATA_DIR_PATH + "/" + model_name))
        model = loader.load()
        self.vaos[model_name] = model.root_nodes[0].mesh.vao.instance(self.prog if (program is None) else program)
        if not (self.outline_renderer is None):
            self.outline_renderer.load_vao(model_name, model)

    def render_model(self,
                     pos, forward, up,
                     model_name, texture, scale = 1.0, global_color = None,
                     mode = moderngl.TRIANGLES, outline_color: Vector3 = None, vert_amount = None):

        if pos is None:
            model_mat = Matrix44.identity()
        else:
            pos = Vector3(pos)
            forward = Vector3(forward)
            up = Vector3(up)
            right = Vector3(pyrr.vector3.cross(forward, up))

            forward *= scale
            right *= scale
            up *= scale

            model_mat = Matrix44([
                forward[0], forward[1], forward[2], 0,
                -right[0], -right[1], -right[2], 0,
                up[0], up[1], up[2], 0,
                pos[0], pos[1], pos[2], 1
            ])

        self.pr_m_model.write(model_mat.astype('f4'))
        self.pra_m_model.write(model_mat.astype('f4'))

        if global_color is None:
            global_color = Vector4((0, 0, 0, 0))
        self.pr_global_color.write(global_color.astype('f4'))

        if texture is not None:
            texture.use()
        else:
            self.t_none.use()

        self.ctx.screen.use()
        self.vaos[model_name].render(mode, vertices=(-1 if (vert_amount is None) else vert_amount))

        if outline_color is not None:
            self.outline_renderer.use_framebuf()
            self.outline_renderer.pr_m_model.write(model_mat.astype('f4'))
            self.outline_renderer.pr_color.write(Vector4((outline_color.x, outline_color.y, outline_color.z, 1)).astype('f4'))
            self.outline_renderer.vaos[model_name].render(mode)

    def render_ribbon(self, ribbon: RibbonEmitter, camera_pos, lifetime, width, start_taper_time, color):
        if len(ribbon.points) == 0:
            return

        vertices = []

        first_point = ribbon.points[0]
        cam_to_ribbon_dir = safe_normalize(-(first_point.pos - camera_pos))
        ribbon_away_dir = safe_normalize(first_point.vel)
        ribbon_sideways_dir = ribbon_away_dir.cross(cam_to_ribbon_dir)

        for point in ribbon.points: # type: RibbonPoint
            if not point.connected:
                continue

            if point.time_active < start_taper_time:
                width_scale = point.time_active / start_taper_time
            else:
                width_scale = 1 - (point.time_active / lifetime)

            offset = ribbon_sideways_dir * width * width_scale
            for i in range(2):
                offset_scale = 1 if (i == 1) else -1
                vertex_pos = point.pos + (offset * offset_scale)
                if len(vertices) < self.ribbon_max_verts:
                    vertices.append(vertex_pos)
                else:
                    break

        if len(vertices) > 0:
            while len(vertices) < self.ribbon_max_verts:
                vertices.append(vertices[-1])
        else:
            return

        self.ribbon_vbo.write(np.array(vertices).astype('f4'), 0)

        glDisable(GL_CULL_FACE)
        self.render_model(
            None, None, None,
            "ribbon", self.t_none, scale=20,
            global_color=color,
            mode=moderngl.TRIANGLE_STRIP
        )
        glEnable(GL_CULL_FACE)

    def calc_camera_state(self, state, interp_ratio, delta_time):
        # Camera mode 0: Manual (click to cycle players, bird's eye)
        if self.camera_mode == 0:
            pos = Vector3((-4000, 0, 1000))
            ball_pos = state.ball_state.get_pos(interp_ratio)
            
            is_spectating_car = self.spectate_idx > -1 and len(state.car_states) > self.spectate_idx
            if is_spectating_car:
                car_pos = state.car_states[self.spectate_idx].phys.get_pos(interp_ratio)
                car_vel = state.car_states[self.spectate_idx].phys.get_vel(interp_ratio)
                car_forward = state.car_states[self.spectate_idx].phys.get_forward(interp_ratio)

                # Calculate ball cam
                height = self.config.camera_height.val
                dist = self.config.camera_distance.val

                ball_cam_offset_dir = safe_normalize(safe_normalize(ball_pos - car_pos) * Vector3((1, 1, 0))).normalized

                # As we tilt up, move the camera down
                lean_scale = safe_normalize(ball_pos - car_pos).z
                height_clamp = abs(ball_pos.z - car_pos.z) / self.config.camera_lean_min_height_clamp.val
                if lean_scale > 0:
                    height *= 1 - min(lean_scale * self.config.camera_lean_height_scale.val, height_clamp)
                    dist *= 1 - lean_scale * self.config.camera_lean_dist_scale.val

                ball_cam_offset = -ball_cam_offset_dir * dist
                ball_cam_offset.z += height
                ball_cam_offset = safe_normalize(ball_cam_offset) * dist
                ball_cam_pos = car_pos + ball_cam_offset
                ball_cam_dir = safe_normalize(ball_pos - ball_cam_pos)

                # Calculate car cam
                if car_vel.length > 0:
                    car_cam_dir = safe_normalize(car_vel * Vector3((1, 1, 0)))
                else:
                    car_cam_dir = car_forward * Vector3((1, 1, 0))
                    if car_cam_dir.length > 0:
                        car_cam_dir = safe_normalize(car_cam_dir)
                    else:
                        car_cam_dir = Vector3((1, 1, 0))
                car_cam_offset = -car_cam_dir * self.config.camera_distance.val
                car_cam_offset.z = self.config.camera_height.val
                car_cam_pos = car_pos + car_cam_offset

                # Determine if dribbling for auto car-cam
                car_ball_delta = ball_pos - car_pos
                dribbling = False
                if car_vel.length > 500:
                    if 90 < car_ball_delta.z < 200:
                        if (car_ball_delta * Vector3((1, 1, 0))).length < 135:
                            if ball_pos.z < 300:
                                dribbling = True

                car_cam_start_delay = 0.25
                car_cam_max_time = 0.65
                car_cam_inc_speed = 0.8
                car_cam_dec_speed = 0.5
                if car_ball_delta.length > 1000:
                    car_cam_dec_speed *= 2

                if dribbling:
                    self.car_cam_time += car_cam_inc_speed * delta_time
                else:
                    self.car_cam_time = min(self.car_cam_time, car_cam_max_time)
                    self.car_cam_time = max(0, self.car_cam_time - car_cam_dec_speed * delta_time)

                car_cam_ratio = np.clip((self.car_cam_time - car_cam_start_delay) / (car_cam_max_time - car_cam_start_delay), 0, 1)
                pos = ball_cam_pos*(1-car_cam_ratio) + car_cam_pos*car_cam_ratio
                cam_dir = safe_normalize(ball_cam_dir*(1-car_cam_ratio) + car_cam_dir*car_cam_ratio)
                return pos, pos + cam_dir, self.config.camera_fov.val
            else:
                # Bird's eye view when no player selected
                cam_dir = safe_normalize(ball_pos - pos)
                return pos, pos + cam_dir, self.config.camera_bird_fov.val
                
        # Camera mode 1: Auto-focus (follows closest player to ball)
        elif self.camera_mode == 1:
            if len(state.car_states) > 0:
                closest_idx = -1
                closest_dist = float('inf')
                ball_phys_pos = state.ball_state.next_pos
                for i in range(len(state.car_states)):
                    player = state.car_states[i]
                    if player.is_demoed:
                        continue
                    dist_to_ball = (player.phys.next_pos - ball_phys_pos).length
                    if dist_to_ball < closest_dist:
                        closest_idx = i
                        closest_dist = dist_to_ball
                
                if closest_idx != -1:
                    self.spectate_idx = closest_idx
                    # Use the same camera logic as manual mode for the focused player
                    return self.calc_camera_state_for_player(state, interp_ratio, closest_idx)
            
            # Fallback to bird's eye if no players
            pos = Vector3((-4000, 0, 1000))
            ball_pos = state.ball_state.get_pos(interp_ratio)
            cam_dir = safe_normalize(ball_pos - pos)
            return pos, pos + cam_dir, self.config.camera_bird_fov.val
            
        # Camera mode 2: Free camera (mouse look + WASD movement)
        elif self.camera_mode == 2:
            move_speed = 2000.0 * delta_time  # Movement speed
            
            # Calculate movement directions
            forward = Vector3((
                math.cos(self.free_cam_yaw),
                math.sin(self.free_cam_yaw),
                0
            ))
            right = Vector3((
                math.cos(self.free_cam_yaw + math.pi/2),
                math.sin(self.free_cam_yaw + math.pi/2),
                0
            ))
            up = Vector3((0, 0, 1))
            
            # Use Qt's real-time key state checking (bypasses stuck key issue)
            from PyQt5.QtWidgets import QApplication
            
            # Check if RocketSimVis window is the active foreground window
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            
            # Get the currently active window
            foreground_window = user32.GetForegroundWindow()
            # Get our parent window handle (not the widget handle)
            our_window = int(self.parent().winId()) if self.parent() else int(self.winId())
            
            # Only allow movement if our window is the active foreground window
            if foreground_window != our_window:
                # Different window is active - no movement and show cursor
                move_vector = Vector3((0, 0, 0))
                self.setCursor(Qt.ArrowCursor)
            else:
                # Build movement vector using real-time key state  
                move_x, move_y, move_z = 0.0, 0.0, 0.0
                
                # Check WASD keys using Windows API
                # But first check if Windows key is pressed (should disable movement)
                if user32.GetAsyncKeyState(0x5B) & 0x8000 or user32.GetAsyncKeyState(0x5C) & 0x8000:  # Left/Right Windows keys
                    # Windows key is pressed - disable movement and show cursor
                    move_x = move_y = move_z = 0.0
                    self.setCursor(Qt.ArrowCursor)
                else:
                    # Windows key not pressed - hide cursor and allow movement
                    self.setCursor(Qt.BlankCursor)
                    if user32.GetAsyncKeyState(ord('W')) & 0x8000:  # W key
                        move_x += forward.x
                        move_y += forward.y
                        move_z += forward.z
                    if user32.GetAsyncKeyState(ord('S')) & 0x8000:  # S key
                        move_x -= forward.x
                        move_y -= forward.y
                        move_z -= forward.z
                    if user32.GetAsyncKeyState(ord('D')) & 0x8000:  # D key
                        move_x += right.x
                        move_y += right.y
                        move_z += right.z
                    if user32.GetAsyncKeyState(ord('A')) & 0x8000:  # A key
                        move_x -= right.x
                        move_y -= right.y
                        move_z -= right.z
                    if user32.GetAsyncKeyState(0x20) & 0x8000:  # Space key
                        move_z += 1.0
                    if user32.GetAsyncKeyState(0x11) & 0x8000:  # Ctrl key
                        move_z -= 1.0
                
                # Create final movement vector
                move_vector = Vector3((move_x, move_y, move_z))
            
            # Apply movement if any
            if move_vector.length > 0:
                move_vector = safe_normalize(move_vector)
                self.free_cam_pos += move_vector * move_speed
            
            # Camera look direction (with pitch)
            look_forward = Vector3((
                math.cos(self.free_cam_yaw) * math.cos(self.free_cam_pitch),
                math.sin(self.free_cam_yaw) * math.cos(self.free_cam_pitch),
                math.sin(self.free_cam_pitch)
            ))
            
            target_pos = self.free_cam_pos + look_forward
            return self.free_cam_pos, target_pos, self.config.camera_fov.val
            
        # Default fallback
        pos = Vector3((-4000, 0, 1000))
        ball_pos = state.ball_state.get_pos(interp_ratio)
        cam_dir = safe_normalize(ball_pos - pos)
        return pos, pos + cam_dir, self.config.camera_bird_fov.val
    
    def calc_camera_state_for_player(self, state, interp_ratio, player_idx):
        # Helper method for player-focused camera (used by auto-focus mode)
        car_pos = state.car_states[player_idx].phys.get_pos(interp_ratio)
        car_vel = state.car_states[player_idx].phys.get_vel(interp_ratio)
        ball_pos = state.ball_state.get_pos(interp_ratio)
        
        height = self.config.camera_height.val
        dist = self.config.camera_distance.val
        
        ball_cam_offset_dir = safe_normalize(safe_normalize(ball_pos - car_pos) * Vector3((1, 1, 0))).normalized
        
        lean_scale = safe_normalize(ball_pos - car_pos).z
        height_clamp = abs(ball_pos.z - car_pos.z) / self.config.camera_lean_min_height_clamp.val
        if lean_scale > 0:
            height *= 1 - min(lean_scale * self.config.camera_lean_height_scale.val, height_clamp)
            dist *= 1 - lean_scale * self.config.camera_lean_dist_scale.val
        
        ball_cam_offset = -ball_cam_offset_dir * dist
        ball_cam_offset.z += height
        ball_cam_offset = safe_normalize(ball_cam_offset) * dist
        ball_cam_pos = car_pos + ball_cam_offset
        ball_cam_dir = safe_normalize(ball_pos - ball_cam_pos)
        
        return ball_cam_pos, ball_cam_pos + ball_cam_dir, self.config.camera_fov.val

    def paintGL(self):
        width, height = self.width(), self.height()
        self.ctx.viewport = (0, 0, width, height)

        cur_time = time.time()
        delta_time = cur_time - self.last_render_time
        self.render(cur_time, delta_time, width, height)

        self.fps_counter += 1

        if int(cur_time) > int(self.last_render_time):
            self.last_fps = self.fps_counter
            self.fps_counter = 2

        self.last_render_time = cur_time

        self.update()

    def render(self, total_time, delta_time, width, height):
        with global_state_mutex:
            if not global_state_manager.state.ball_state.has_rot:
                global_state_manager.state.ball_state.rotate_with_ang_vel(delta_time)

            state = copy.deepcopy(global_state_manager.state)
        self.prev_state = state
        self.spectate_count = len(state.car_states)

        while len(self.car_ribbons) != len(state.car_states):
            if len(self.car_ribbons) < len(state.car_states):
                self.car_ribbons.append(RibbonEmitter())
            else:
                self.car_ribbons.pop()

        cur_time = time.time()
        interp_interval = max(state.recv_interval, 1e-6)
        interp_ratio = min(max((cur_time - state.recv_time) / interp_interval, 0), 1)

        # Goal detection - check if ball reset to center
        ball_pos = state.ball_state.get_pos(interp_ratio)
        
        # Cooldown to prevent double-counting
        if self.goal_scored_cooldown > 0:
            self.goal_scored_cooldown -= delta_time
        
        # Detect goal: ball teleports back to center (kickoff position)
        if self.last_ball_pos is not None and self.goal_scored_cooldown <= 0:
            # Check if ball teleported (large distance change)
            distance_moved = (ball_pos - self.last_ball_pos).length
            ball_at_center = abs(ball_pos.x) < 100 and abs(ball_pos.y) < 100 and abs(ball_pos.z - 93) < 50
            
            if distance_moved > 1000 and ball_at_center:
                # Ball reset to kickoff - goal was scored!
                # Determine which goal by checking last ball position
                if self.last_ball_pos.y > 5000:  # Orange goal (positive Y)
                    self.blue_score += 1
                    self.goal_explosion_active = True
                    self.goal_explosion_time = 0
                    self.goal_explosion_team = 0
                    self.goal_explosion_pos = self.last_ball_pos.copy()
                elif self.last_ball_pos.y < -5000:  # Blue goal (negative Y)
                    self.orange_score += 1
                    self.goal_explosion_active = True
                    self.goal_explosion_time = 0
                    self.goal_explosion_team = 1
                    self.goal_explosion_pos = self.last_ball_pos.copy()
                
                self.goal_scored_cooldown = 2.0  # 2 second cooldown
        
        self.last_ball_pos = ball_pos.copy()

        if not (self.outline_renderer is None):
            self.outline_renderer.clear()

        self.ctx.clear(0, 0, 0)
        self.ctx.enable(moderngl.DEPTH_TEST)
        self.ctx.enable(moderngl.BLEND)

        self.ctx.cull_face = "back"
        self.ctx.front_face = "cw"
        self.ctx.enable(moderngl.CULL_FACE)

        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA) # Normal blending
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR) # Use linear interpolation of pixels for supersampling

        camera_pos, camera_target_pos, camera_fov = self.calc_camera_state(state, interp_ratio, delta_time)
        proj = Matrix44.perspective_projection(camera_fov, -width/height, 0.1, 50 * 1000.0)
        lookat = Matrix44.look_at(
            camera_pos,
            camera_target_pos,
            (0.0, 0.0, 1.0),
        )

        self.pr_camera_pos.write(camera_pos.astype('f4'))
        self.pr_m_vp.write((proj * lookat).astype('f4'))
        self.pra_m_vp.write((proj * lookat).astype('f4'))
        if not (self.outline_renderer is None):
            self.outline_renderer.pr_m_vp.write((proj * lookat).astype('f4'))

        if not (state.boost_pad_states is None) and state.gamemode != "heatseeker": # Render boost pads
            for i in range(len(state.boost_pad_states)):
                is_big = state.is_boost_big(i)
                is_active = state.boost_pad_states[i]

                pos = state.boost_pad_locations[i].copy()
                pos.z = 0

                model_name = "BoostPad"
                model_name += "_Big_" if is_big else "_Small_"
                model_name += "1" if is_active else "0"
                model_name += ".obj"

                self.render_model(
                    pos, Vector3((1, 0, 0)), Vector3((0, 0, 1)),
                    model_name,
                    self.t_boostpad,
                    scale=2.5,
                )

        if True: # Render ball
            ball_phys = state.ball_state
            ball_pos = ball_phys.get_pos(interp_ratio)
            self.render_model(
                ball_pos,
                ball_phys.get_forward(interp_ratio), ball_phys.get_up(interp_ratio), 'Ball.obj', self.t_ball,

                #outline_color = Vector4((1, 1, 1, 1))
            )

            

            if state.gamemode == "heatseeker": # Update and render ball ribbon
                ball_speed = ball_phys.get_vel(interp_ratio).length
                speed_frac = (max(0, min(1, ball_speed / 2800)) ** 2)
                ribbon_alpha = 0.75
                ribbon_lifetime = 0.8

                self.ball_ribbon.update(
                    ball_speed > 600,
                    0,
                    ball_pos,
                    Vector3((100,0,0)),
                    ribbon_lifetime,
                    delta_time
                )

                if ball_phys.is_teleporting():
                    self.ball_ribbon.points.clear()

                self.render_ribbon(
                    self.ball_ribbon,
                    camera_pos,
                    ribbon_lifetime,
                    width=50,
                    start_taper_time=ribbon_lifetime / 10,
                    color=Vector4((1, 1, 1, ribbon_alpha))
                )

        if True: # Render cars
            for i in range(len(state.car_states)):
                car_state = state.car_states[i]
                if car_state.is_demoed:
                    continue

                car_ribbon = self.car_ribbons[i]

                car_pos = car_state.phys.get_pos(interp_ratio)
                car_forward = car_state.phys.get_forward(interp_ratio)
                car_up = car_state.phys.get_up(interp_ratio)
                outline_brightness = 1 - (1 / (1 + (car_pos - camera_pos).length / 1000))
                self.render_model(
                    car_pos, car_forward, car_up,
                    model_name='Octane.obj', texture=self.ts_octane[car_state.team_num],

                    #outline_color = (Vector3((0, 0.5, 1)) if (car_state.team_num == 0) else Vector3((1, 0.5, 0))) * outline_brightness
                )

                if True: # Update and render car ribbon
                    RIBBON_LIFETIME = 0.3
                    ribbon_emit_pos = car_pos - (car_forward * 40) + (car_up * 10)
                    ribbon_vel = car_forward * -100
                    car_ribbon.update(
                        car_state.is_boosting,
                        0,
                        ribbon_emit_pos,
                        ribbon_vel,
                        RIBBON_LIFETIME,
                        delta_time
                    )

                    if car_state.phys.is_teleporting():
                        car_ribbon.points.clear()

                    self.render_ribbon(
                        car_ribbon,
                        camera_pos,
                        RIBBON_LIFETIME,
                        20,
                        RIBBON_LIFETIME / 10,
                        Vector4((1, 0.9, 0.4, 1))
                    )

        ###########################################

        self.pra_ball_pos.write(state.ball_state.get_pos(interp_ratio).astype('f4'))
        self.render_model(
            None, None, None,
            model_name='ArenaMeshCustom.obj', texture=self.t_none, scale=1, global_color=Vector4((1,1,1,1))
        )

        if not (self.outline_renderer is None):
            self.outline_renderer.render_quad()

        ###########################################

        if len(state.render_state.lines) > 0:
            vertices_flat = np.array(state.render_state.lines).flatten()
            num_verts = vertices_flat.shape[0] // 3
            # TODO: Manual construction of VBO and VAO every frame is very inefficient
            # Instead, maybe keep a buffer of the max number of vertices and do a partial render from the occupied regions
            self.lines_vbo.write(vertices_flat.astype('f4'))
            self.ctx.disable(moderngl.DEPTH_TEST)
            self.render_model(
                None, None, None,
                "render_lines", self.t_boost_glow, 1, Vector4((1, 1, 1, 1)),
                mode=GL_LINES,
                vert_amount=num_verts
            )
            self.ctx.enable(moderngl.DEPTH_TEST)

        ###########################################
        # GOAL EXPLOSION
        if self.goal_explosion_active:
            self.goal_explosion_time += delta_time
            explosion_duration = 1.5
            
            if self.goal_explosion_time > explosion_duration:
                self.goal_explosion_active = False
            else:
                # Explosion progress (0 to 1)
                progress = self.goal_explosion_time / explosion_duration
                
                # Team color
                if self.goal_explosion_team == 0:  # Blue
                    team_color = Vector3((0.3, 0.6, 1.0))
                else:  # Orange
                    team_color = Vector3((1.0, 0.6, 0.2))
                
                # Expanding shockwave rings (horizontal only, on the ground)
                self.pr_m_vp.write((proj * lookat).astype('f4'))
                num_rings = 3
                for ring_idx in range(num_rings):
                    ring_delay = ring_idx * 0.15
                    ring_progress = max(0, min(1, (progress - ring_delay) / (1 - ring_delay)))
                    
                    if ring_progress > 0:
                        ring_radius = 300 + ring_progress * 1000
                        ring_alpha = (1 - ring_progress) * 0.7
                        
                        segments = 48
                        ring_verts = []
                        
                        # Draw ring on the ground (z=50)
                        for i in range(segments + 1):
                            angle = (i / segments) * 2 * math.pi
                            x = self.goal_explosion_pos.x + ring_radius * math.cos(angle)
                            y = self.goal_explosion_pos.y + ring_radius * math.sin(angle)
                            z = 50  # Just above ground
                            ring_verts.append(Vector3((x, y, z)))
                        
                        ring_array = np.array(ring_verts).flatten()
                        self.lines_vbo.write(ring_array.astype('f4'))
                        self.render_model(None, None, None, "render_lines", self.t_boost_glow, 1,
                                          Vector4((team_color.x, team_color.y, team_color.z, ring_alpha)),
                                          mode=GL_LINE_STRIP, vert_amount=len(ring_verts))
                
                # Particle burst (lots of flying dots)
                num_particles = 60
                particle_verts = []
                
                for i in range(num_particles):
                    # Deterministic random based on particle index
                    angle_xz = (i * 2.4) % (2 * math.pi)
                    angle_y = ((i * 1.7) % 1.0 - 0.5) * math.pi * 0.5
                    
                    speed = 800 + (i % 5) * 150
                    vel_x = math.cos(angle_xz) * math.cos(angle_y) * speed
                    vel_y = math.sin(angle_xz) * math.cos(angle_y) * speed
                    vel_z = math.sin(angle_y) * speed + 300
                    
                    # Particle position (centered on goal explosion position)
                    pos_x = self.goal_explosion_pos.x + vel_x * progress
                    pos_y = self.goal_explosion_pos.y + vel_y * progress
                    pos_z = self.goal_explosion_pos.z + vel_z * progress - 400 * progress * progress
                    
                    if pos_z > 20:  # Only show particles above ground
                        particle_verts.append(Vector3((pos_x, pos_y, pos_z)))
                
                if len(particle_verts) > 0:
                    particle_array = np.array(particle_verts).flatten()
                    self.lines_vbo.write(particle_array.astype('f4'))
                    glPointSize(12)
                    self.render_model(None, None, None, "render_lines", self.t_boost_glow, 1,
                                      Vector4((team_color.x, team_color.y, team_color.z, (1 - progress) * 0.85)),
                                      mode=GL_POINTS, vert_amount=len(particle_verts))
                    glPointSize(1)

        ###########################################

        ui_text = ""
        ui_text += "Render FPS: {}".format(self.last_fps) + "\n"
        ui_text += "Connected: {}".format(state.recv_time > 0) + "\n"
        if state.total_timesteps > 0:
            ui_text += "Timesteps: {:,}\n".format(state.total_timesteps)
        if state.recv_interval > 0:
            ui_text += "Network rate: {:.2f}fps".format(1 / state.recv_interval) + "\n"
        
        # Camera mode indicator
        if self.camera_mode == 0:
            ui_text += "Camera: Manual"
            if self.spectate_idx >= 0:
                ui_text += " (Player {})\n".format(self.spectate_idx + 1)
            else:
                ui_text += " (Bird's eye)\n"
        elif self.camera_mode == 1:
            ui_text += "Camera: Auto-focus"
            if self.spectate_idx >= 0:
                ui_text += " (Player {})\n".format(self.spectate_idx + 1)
            else:
                ui_text += "\n"
        elif self.camera_mode == 2:
            ui_text += "Camera: Free\n"
            ui_text += "Pos: ({:.0f}, {:.0f}, {:.0f})\n".format(
                self.free_cam_pos.x, self.free_cam_pos.y, self.free_cam_pos.z
            )
            ui_text += "R: Reset position\n"
        
        ui_text += "Ball speed: {:.2f}kph".format(state.ball_state.prev_vel.length * (9 / 250)) + "\n"
        ui_text += "Ball height: {:.1f}\n".format(state.ball_state.get_pos(interp_ratio).z)
        
        is_spectating_car = self.spectate_idx > -1 and len(state.car_states) > self.spectate_idx
        if is_spectating_car:
            car_state = state.car_states[self.spectate_idx]
            ui_text += "Player boost: {}\n".format(round(car_state.boost_amount * 100))
            car_speed_kph = car_state.phys.get_vel(interp_ratio).length * (9 / 250)
            ui_text += "Player speed: {:.0f}kph\n".format(car_speed_kph)
            ui_text += "Player height: {:.1f}\n".format(car_state.phys.get_pos(interp_ratio).z)
        
        ui_text += "\nF1: Manual | F2: Auto | F3: Free | ESC: Exit Free | F11: Fullscreen"

        get_ui().set_text(ui_text)

        # Draw crosshair for free camera mode
        if self.camera_mode == 2:
            center_x, center_y = width // 2, height // 2
            crosshair_size = 12
            
            crosshair_lines = [
                Vector3((center_x - crosshair_size, center_y, 0)),
                Vector3((center_x + crosshair_size, center_y, 0)),
                Vector3((center_x, center_y - crosshair_size, 0)),
                Vector3((center_x, center_y + crosshair_size, 0))
            ]
            
            crosshair_verts = np.array(crosshair_lines).flatten()
            
            # Set 2D overlay projection
            ortho_proj = Matrix44.orthogonal_projection(0, width, height, 0, -1, 1)
            self.pr_m_vp.write(ortho_proj.astype('f4'))
            
            self.lines_vbo.write(crosshair_verts.astype('f4'))
            self.ctx.disable(moderngl.DEPTH_TEST)
            
            self.render_model(
                None, None, None,
                "render_lines", self.t_none, 1, Vector4((1, 1, 1, 0.9)),
                mode=GL_LINES,
                vert_amount=4
            )
            
            self.ctx.enable(moderngl.DEPTH_TEST)

        ###########################################

        # Draw boost meter in bottom right
        if len(state.car_states) > 0:
            # Show boost for spectated player, or player 0 if none selected
            player_idx = self.spectate_idx if (self.spectate_idx >= 0 and self.spectate_idx < len(state.car_states)) else 0
            player_boost = state.car_states[player_idx].boost_amount
            radius = 60  # Increased from 50
            margin = 40  # Increased from 30
            center_x = width - radius - margin
            center_y = height - radius - margin
            segments = 64

            ortho_proj = Matrix44.orthogonal_projection(0, width, height, 0, -1, 1)
            self.pr_m_vp.write(ortho_proj.astype('f4'))
            self.ctx.disable(moderngl.DEPTH_TEST)

            # Draw shadow (offset circle, darker)
            shadow_offset = 3
            shadow_verts = [Vector3((center_x + shadow_offset, center_y + shadow_offset, 0))]
            for i in range(segments + 1):
                angle = (i / segments) * 2 * math.pi
                x = center_x + shadow_offset + radius * math.cos(angle)
                y = center_y + shadow_offset + radius * math.sin(angle)
                shadow_verts.append(Vector3((x, y, 0)))
            shadow_array = np.array(shadow_verts).flatten()
            self.lines_vbo.write(shadow_array.astype('f4'))
            self.render_model(None, None, None, "render_lines", self.t_none, 1,
                              Vector4((0.0, 0.0, 0.0, 0.5)),
                              mode=GL_TRIANGLE_FAN, vert_amount=len(shadow_verts))

            # Draw background circle (filled) with subtle gradient effect
            circle_verts = [Vector3((center_x, center_y, 0))]  # Center point
            for i in range(segments + 1):
                angle = (i / segments) * 2 * math.pi
                x = center_x + radius * math.cos(angle)
                y = center_y + radius * math.sin(angle)
                circle_verts.append(Vector3((x, y, 0)))

            circle_array = np.array(circle_verts).flatten()
            self.lines_vbo.write(circle_array.astype('f4'))
            self.render_model(None, None, None, "render_lines", self.t_none, 1,
                              Vector4((0.1, 0.1, 0.1, 0.95)),
                              mode=GL_TRIANGLE_FAN, vert_amount=len(circle_verts))

            # Draw outer ring border
            outer_radius = radius + 2
            ring_verts = []
            for i in range(segments + 1):
                angle = (i / segments) * 2 * math.pi
                x = center_x + outer_radius * math.cos(angle)
                y = center_y + outer_radius * math.sin(angle)
                ring_verts.append(Vector3((x, y, 0)))
            ring_array = np.array(ring_verts).flatten()
            self.lines_vbo.write(ring_array.astype('f4'))
            self.render_model(None, None, None, "render_lines", self.t_none, 1,
                              Vector4((0.3, 0.3, 0.3, 0.8)),
                              mode=GL_LINE_STRIP, vert_amount=len(ring_verts))

            # Draw boost arc (starts at top, goes clockwise)
            if player_boost > 0:
                boost_ratio = player_boost  # Already 0-1, not 0-100
                boost_segments = int(boost_ratio * segments)

                # Color based on boost amount (0-1 scale)
                if player_boost > 0.66:
                    color = Vector4((1.0, 0.9, 0.1, 0.98))  # Bright gold
                elif player_boost > 0.33:
                    color = Vector4((1.0, 0.65, 0.0, 0.98))  # Vibrant orange
                else:
                    color = Vector4((1.0, 0.25, 0.1, 0.98))  # Bright red

                # Pulsing effect when low on boost
                alpha_pulse = 1.0
                if player_boost < 0.33:
                    pulse_speed = 3.0
                    alpha_pulse = 0.7 + 0.3 * abs(math.sin(total_time * pulse_speed))
                    color.w *= alpha_pulse

                arc_verts = [Vector3((center_x, center_y, 0))]  # Center point
                for i in range(boost_segments + 1):
                    # Start at top (-pi/2), go clockwise
                    angle = (-math.pi / 2) + (i / segments) * 2 * math.pi
                    x = center_x + radius * math.cos(angle)
                    y = center_y + radius * math.sin(angle)
                    arc_verts.append(Vector3((x, y, 0)))

                arc_array = np.array(arc_verts).flatten()
                self.lines_vbo.write(arc_array.astype('f4'))
                self.render_model(None, None, None, "render_lines", self.t_none, 1,
                                  color, mode=GL_TRIANGLE_FAN, vert_amount=len(arc_verts))

                # Draw glow layer (slightly larger, more transparent)
                glow_radius = radius + 4
                glow_verts = [Vector3((center_x, center_y, 0))]
                for i in range(boost_segments + 1):
                    angle = (-math.pi / 2) + (i / segments) * 2 * math.pi
                    x = center_x + glow_radius * math.cos(angle)
                    y = center_y + glow_radius * math.sin(angle)
                    glow_verts.append(Vector3((x, y, 0)))
                glow_array = np.array(glow_verts).flatten()
                self.lines_vbo.write(glow_array.astype('f4'))
                glow_color = Vector4((color.x, color.y, color.z, color.w * 0.3))
                self.render_model(None, None, None, "render_lines", self.t_none, 1,
                                  glow_color, mode=GL_TRIANGLE_FAN, vert_amount=len(glow_verts))

            # Draw boost number in center
            boost_num = int(player_boost * 100)
            num_str = str(boost_num)
            
            # Simple digit rendering using lines
            digit_width = 14  # Increased from 12
            digit_height = 24  # Increased from 20
            digit_spacing = 4  # Increased from 3
            total_width = len(num_str) * (digit_width + digit_spacing) - digit_spacing
            start_x = center_x - total_width / 2
            
            # 7-segment style digit patterns (top, top-right, bottom-right, bottom, bottom-left, top-left, middle)
            segments = {
                '0': [1,1,1,1,1,1,0],
                '1': [0,1,1,0,0,0,0],
                '2': [1,1,0,1,1,0,1],
                '3': [1,1,1,1,0,0,1],
                '4': [0,1,1,0,0,1,1],
                '5': [1,0,1,1,0,1,1],
                '6': [1,0,1,1,1,1,1],
                '7': [1,1,1,0,0,0,0],
                '8': [1,1,1,1,1,1,1],
                '9': [1,1,1,1,0,1,1]
            }
            
            number_verts = []
            for i, digit in enumerate(num_str):
                if digit in segments:
                    dx = start_x + i * (digit_width + digit_spacing)
                    dy = center_y
                    segs = segments[digit]
                    
                    # Top
                    if segs[0]:
                        number_verts.extend([Vector3((dx, dy - digit_height/2, 0)), Vector3((dx + digit_width, dy - digit_height/2, 0))])
                    # Top-right
                    if segs[1]:
                        number_verts.extend([Vector3((dx + digit_width, dy - digit_height/2, 0)), Vector3((dx + digit_width, dy, 0))])
                    # Bottom-right
                    if segs[2]:
                        number_verts.extend([Vector3((dx + digit_width, dy, 0)), Vector3((dx + digit_width, dy + digit_height/2, 0))])
                    # Bottom
                    if segs[3]:
                        number_verts.extend([Vector3((dx + digit_width, dy + digit_height/2, 0)), Vector3((dx, dy + digit_height/2, 0))])
                    # Bottom-left
                    if segs[4]:
                        number_verts.extend([Vector3((dx, dy + digit_height/2, 0)), Vector3((dx, dy, 0))])
                    # Top-left
                    if segs[5]:
                        number_verts.extend([Vector3((dx, dy, 0)), Vector3((dx, dy - digit_height/2, 0))])
                    # Middle
                    if segs[6]:
                        number_verts.extend([Vector3((dx, dy, 0)), Vector3((dx + digit_width, dy, 0))])
            
            if len(number_verts) > 0:
                number_array = np.array(number_verts).flatten()
                self.lines_vbo.write(number_array.astype('f4'))
                self.render_model(None, None, None, "render_lines", self.t_none, 1,
                                  Vector4((1, 1, 1, 1)),
                                  mode=GL_LINES, vert_amount=len(number_verts))

            self.ctx.enable(moderngl.DEPTH_TEST)

#         # Draw boost meter in bottom right
#         if len(state.car_states) > 0:
#             player_boost = state.car_states[0].boost_amount
#             radius = 50
#             margin = 30
#             center_x = width - radius - margin
#             center_y = height - radius - margin
#             segments = 32
# 
#             ortho_proj = Matrix44.orthogonal_projection(0, width, height, 0, -1, 1)
#             self.pr_m_vp.write(ortho_proj.astype('f4'))
#             self.ctx.disable(moderngl.DEPTH_TEST)
# 
#             # Outer circle background
#             circle_verts = []
#             for i in range(segments):
#                 angle1 = (i / segments) * 2 * math.pi
#                 angle2 = ((i + 1) / segments) * 2 * math.pi
#                 x1 = center_x + radius * math.cos(angle1)
#                 y1 = center_y + radius * math.sin(angle1)
#                 x2 = center_x + radius * math.cos(angle2)
#                 y2 = center_y + radius * math.sin(angle2)
#                 circle_verts.append(Vector3((x1, y1, 0)))
#                 circle_verts.append(Vector3((x2, y2, 0)))
# 
#             circle_array = np.array(circle_verts).flatten()
#             self.lines_vbo.write(circle_array.astype('f4'))
#             self.render_model(None, None, None, "render_lines", self.t_none, 1,
#                               Vector4((0.3, 0.3, 0.3, 0.9)),
#                               mode=GL_LINES, vert_amount=len(circle_verts))
# 
#             # Boost arc (top start)
#             if player_boost > 0:
#                 boost_segments = int((player_boost / 100.0) * segments)
#                 arc_verts = []
# 
#                 if player_boost > 66:
#                     color = Vector4((1.0, 0.8, 0.0, 0.95))  # Gold
#                 elif player_boost > 33:
#                     color = Vector4((1.0, 0.5, 0.0, 0.95))  # Orange
#                 else:
#                     color = Vector4((1.0, 0.2, 0.0, 0.95))  # Red
# 
#                 for i in range(boost_segments):
#                     angle1 = (-math.pi / 2) + (i / segments) * 2 * math.pi
#                     angle2 = (-math.pi / 2) + ((i + 1) / segments) * 2 * math.pi
#                     inner_radius = radius - 8
#                     x1_outer = center_x + radius * math.cos(angle1)
#                     y1_outer = center_y + radius * math.sin(angle1)
#                     x2_outer = center_x + radius * math.cos(angle2)
#                     y2_outer = center_y + radius * math.sin(angle2)
#                     x1_inner = center_x + inner_radius * math.cos(angle1)
#                     y1_inner = center_y + inner_radius * math.sin(angle1)
#                     x2_inner = center_x + inner_radius * math.cos(angle2)
#                     y2_inner = center_y + inner_radius * math.sin(angle2)
#                     arc_verts.extend([
#                         Vector3((x1_outer, y1_outer, 0)),
#                         Vector3((x2_outer, y2_outer, 0)),
#                         Vector3((x1_inner, y1_inner, 0)),
#                         Vector3((x2_inner, y2_inner, 0)),
#                     ])
# 
#                 arc_array = np.array(arc_verts).flatten()
#                 self.lines_vbo.write(arc_array.astype('f4'))
#                 self.render_model(None, None, None, "render_lines", self.t_none, 1,
#                                   color, mode=GL_LINES, vert_amount=len(arc_verts))
# 
#             self.ctx.enable(moderngl.DEPTH_TEST)
#             get_ui().set_boost(player_boost, width, height)
#         else:
#             get_ui().set_boost(-1, width, height)

        self.prev_interp_ratio = interp_ratio

        ####################################################

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            # Only allow manual cycling in manual mode
            if self.camera_mode == 0:
                if self.spectate_count == 0:
                    return
                self.spectate_idx += 1
                if self.spectate_idx >= self.spectate_count:
                    self.spectate_idx = -1
                    
    def mouseMoveEvent(self, event):
        # Only handle mouse look in free camera mode
        if self.camera_mode == 2:
            if self.mouse_last_x is not None and self.mouse_last_y is not None:
                dx = event.x() - self.mouse_last_x
                dy = event.y() - self.mouse_last_y

                sensitivity = 0.015  # mouse sensitivity
                self.free_cam_yaw += dx * sensitivity
                self.free_cam_pitch -= dy * sensitivity

                # --- Normalize yaw and clamp pitch properly ---
                if self.free_cam_yaw > math.pi:
                    self.free_cam_yaw -= 2 * math.pi
                elif self.free_cam_yaw < -math.pi:
                    self.free_cam_yaw += 2 * math.pi

                # Never allow pitch to reach ±90°, stop around 89° to avoid gimbal lock
                limit = math.radians(89.0)
                self.free_cam_pitch = max(-limit, min(limit, self.free_cam_pitch))

            self.mouse_last_x = event.x()
            self.mouse_last_y = event.y()

    def keyPressEvent(self, event):
        # Clear stuck keys first (focus fix)
        if event.key() in [Qt.Key_F1, Qt.Key_F2, Qt.Key_F3]:
            self.keys_pressed.clear()
        
        # Track key state for WASD movement
        self.keys_pressed.add(event.key())
        
        # F1: Manual camera mode
        if event.key() == Qt.Key_F1:
            self.camera_mode = 0
            # Show cursor again
            self.setCursor(Qt.ArrowCursor)
            print("Camera mode: Manual")
        
        # F2: Auto-focus camera mode  
        elif event.key() == Qt.Key_F2:
            self.camera_mode = 1
            # Show cursor again
            self.setCursor(Qt.ArrowCursor)
            print("Camera mode: Auto-focus")
        
        # F3: Free camera mode
        elif event.key() == Qt.Key_F3:
            self.camera_mode = 2
            # Reset mouse tracking when entering free cam
            center_x = self.width() // 2
            center_y = self.height() // 2
            self.mouse_last_x = center_x
            self.mouse_last_y = center_y
            # Hide cursor and release any mouse capture
            self.setCursor(Qt.BlankCursor)
            self.releaseMouse()  # Ensure no mouse capture initially
            print("Camera mode: Free (mouse look only)")
            
        # F11: Toggle fullscreen
        elif event.key() == Qt.Key_F11:
            parent = self.parent()
            if parent:
                if parent.isFullScreen():
                    # Exit fullscreen - restore previous state
                    if self.was_maximized_before_fullscreen:
                        parent.showMaximized()
                    else:
                        parent.showNormal()
                    print("Exited fullscreen")
                else:
                    # Enter fullscreen - remember current state
                    self.was_maximized_before_fullscreen = parent.isMaximized()
                    parent.showFullScreen()
                    print("Entered fullscreen")
                    
        # ESC: Pause simulation and show cursor
        elif event.key() == Qt.Key_Escape:
            if self.camera_mode == 2:
                # Exit free cam mode and show cursor
                self.camera_mode = 0
                self.setCursor(Qt.ArrowCursor)
                self.releaseMouse()  # Release any mouse capture
                print("Simulation paused - cursor restored (F3 to resume free cam)")
            else:
                print("ESC: Use F3 for free camera mode")
            
        # Free camera controls (only when in free cam mode)
        if self.camera_mode == 2:
            # R: Reset camera to center above field
            if event.key() == Qt.Key_R:
                self.free_cam_pos = Vector3((0, 0, 500))
                self.free_cam_yaw = 0.0
                self.free_cam_pitch = -0.3
                print("Free cam reset")
            
        # P: Quick switch to closest player (works in manual mode)
        elif event.key() == Qt.Key_P and self.camera_mode == 0:
            if not (self.prev_state is None):
                closest_idx = -1
                closest_dist = 100_000
                for i in range(len(self.prev_state.car_states)):
                    player = self.prev_state.car_states[i]
                    dist_to_ball = (player.phys.next_pos - self.prev_state.ball_state.next_pos).length
                    if dist_to_ball < closest_dist:
                        closest_idx = i
                        closest_dist = dist_to_ball
                self.spectate_idx = closest_idx
    
    def keyReleaseEvent(self, event):
        # Stop tracking released keys
        self.keys_pressed.discard(event.key())
        
    def focusInEvent(self, event):
        # Refresh OpenGL context when window regains focus (fixes black screen)
        super().focusInEvent(event)
        self.update()  # Force a repaint
        
    def focusOutEvent(self, event):
        # Clear all keys when window loses focus (prevents stuck keys)
        self.keys_pressed.clear()
        super().focusOutEvent(event)



g_socket_listener = None
def run_socket_thread(port):
    global g_socket_listener
    g_socket_listener = SocketListener()
    g_socket_listener.run(port)

def main():
    #cmd_args = arg_parser.parse_args()
    port = 9273
    
    print("Starting RocketSimVis...")

    print("Starting socket thread...")
    socket_thread = threading.Thread(target=run_socket_thread, args=(int(port),))
    socket_thread.start()

    print("Starting visualizer window...")

    app = QtWidgets.QApplication([])
    ui.update_scaling_factor(app)

    window = QRSVWindow(QRSVGLWidget(app.primaryScreen()))
    window.showNormal()
    app.exec_()

    print("Shutting down...")
    g_socket_listener.stop_async()
    exit()

if __name__ == "__main__":
    main()