These are the files people tend to use to help an AI agent develop the understanding of what GigaLearn is.
You can upload these files to an individual chat or a project.
Personally, I would recommend using either of the following:

- Cursor (IDE)
- Claude Desktop (Claude Code)
- ChatGPT (Projects)
- Gemini
- DeepSeek

That does not mean these are the best reasoning models in the world, but rather the easiest bet to use these files with.
Once you upload these files to a project, or a chat, the agent will be much more confident on how the framework works through rewards, structure, mathematics, meaning it will be able to be more consistent with accuracy.
This does not mean the AI will not make mistakes, though. It will.
I have added this information already in general_advice.md under "Using AI to Help You (Claude, ChatGPT, etc.)"

For ChatGPT, Cursor and Claude:
Simply unzip this zipped folder, drag the .txt's into a project and each time you start a new chat, you will be able to instantly refresh the agent's memory with enough details to understand the framework well.

For Gemini, DeepSeek and others:
Unzip the zipped folder and individually drag the .txt's into a chat. Considering these are ~1MB+ condensed together, some chats may struggle to infer them properly.
Projects are NOT supported (as of 2025) on the following websites, however they are better than the models above at comprehending larger files.
